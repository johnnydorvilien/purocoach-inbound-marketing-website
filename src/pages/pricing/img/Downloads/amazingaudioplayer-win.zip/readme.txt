Amazing Audio Player
Version 4.1
Copyright 2019 Magic Hills Pty Ltd
http://amazingaudioplayer.com/


Overview
-----------------------------------------------------------------------

Amazing Audio Player is an easy-to-use Windows & Mac app that enables you to create HTML5 audio player for your website. The music player works on iPhone, iPad, Android and all modern web browsers including Firefox, Chrome, Opera, Safari, Internet Explorer 7, 8, 9, 10 and 11.

Links
-----------------------------------------------------------------------

Terms of Use: https://amazingaudioplayer.com/terms-of-use/
Download Free Versions for Windows and Mac:  http://amazingaudioplayer.com/downloads/
Online Examples:  http://amazingaudioplayer.com/examples/
Upgrade to Commercial Versions:  http://amazingaudioplayer.com/order/
Quick Start Guide:  http://amazingaudioplayer.com/help/
Contact Us: http://amazingaudioplayer.com/contact/