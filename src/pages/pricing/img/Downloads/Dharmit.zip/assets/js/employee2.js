var employes = [];
var myIndex;
function addemploye() {
  //  console.log(document.getElementById("myCheck").value)

  var employee = document.forms[0];
  var txt = "";
  var i;
  for (i = 0; i < employee.length; i++) {
    if (employee[i].checked) {

      txt = txt + employee[i].value + " ";
    }

    // else if (employee[i = 2].checked) {

    //   txt = txt + employee[i = 2].value + " , ";
    // }

  }
  document.getElementById("employeedp").value = txt;



  var list = document.getElementsByName('dp');
  for (var i = 0; i < list.length; i++) {
    if (list[i].checked) {
      document.getElementById("rbutton").value = list[i].value;

    }
  }


  const chooseFile = document.getElementById("choose-file");
  const imgPreview = document.getElementById("img-preview");

  chooseFile.addEventListener("change", function () {
    getImgData();
  });

  const files = chooseFile.files[0];
  if (files) {
    const fileReader = new FileReader();
    fileReader.readAsDataURL(files);
    fileReader.addEventListener("load", function () {
      imgPreview.style.display = "block";
      imgPreview.innerHTML = '<img src="' + this.result + '" >';
    });
  }




  // var x = document.getElementById("myFile").value;
  // // document.getElementById("f11").innerHTML = x;

  var newemploye = {
    name: document.getElementById("employe-name").value,
    lname: document.getElementById("employe-lname").value,
    date: document.getElementById("employe-date").value,
    salary: document.getElementById("employe-salary").value,
    email: document.getElementById("employe-email").value,
    employee: document.getElementById("employeedp").value,
    dp: document.getElementById("rbutton").value,
    fileup: document.getElementById("choose-file").value,

    // f111: document.getElementById("f11").innerHTML = x,
  }
  employes.push(newemploye)
  displayemployes()

  document.getElementById("myForm").reset();


}





function displayemployes() {
  document.getElementById("form-list-employe-body").innerHTML = ""
  for (i = 0; i < employes.length; i++) {
    var myTr = document.createElement("tr")
    for (a in employes[i]) {
      var mytd = document.createElement("td")
      mytd.innerHTML = employes[i][a]
      myTr.appendChild(mytd)

    }

    var actionTd = document.createElement("td")
    var editBtn = document.createElement("button")
    editBtn.innerHTML = "Edit"
    editBtn.setAttribute("class", "btn btn-sm btn-primary")
    editBtn.setAttribute("onclick", "editemploye(" + i + ")")

    var deletebtn = document.createElement("button")
    deletebtn.innerHTML = "Delete"
    deletebtn.setAttribute("class", "btn btn-sm btn-danger ")
    deletebtn.setAttribute("onclick", "deleteemploye(" + i + ")")

    actionTd.appendChild(editBtn)
    actionTd.appendChild(deletebtn)
    myTr.appendChild(actionTd)
    document.getElementById("form-list-employe-body").appendChild(myTr)


  }
  document.getElementById("employe-name").value = "";
  document.getElementById("employe-lname").value = "";
  document.getElementById("employe-date").value = "";
  document.getElementById("employe-salary").value = "";
  document.getElementById("employe-email").value = "";
  document.getElementById("employeedp").value = "";
  document.getElementById("rbutton").value = "";
  // document.getElementById("myCheck").value="";

}



function updemploye() {
  var updatedemploye = {
    name: document.getElementById("employe-name").value,
    lname: document.getElementById("employe-lname").value,
    date: document.getElementById("employe-date").value,
    salary: document.getElementById("employe-salary").value,
    email: document.getElementById("employe-email").value,
    employee: document.getElementById("employeedp").value,
    dp: document.getElementById("rbutton").value,
    // myCheck:document.getElementById("myCheck").value,
    // js:document.getElementById("js").value,
  }
  employes[myIndex] = updatedemploye;
  var crbtn = document.createElement("button")
  crbtn.innerHTML = "Save";
  crbtn.setAttribute("onclick", "addemploye()")
  crbtn.setAttribute("class", "btn btn-sm btn-success")
  document.getElementById("saveupdate").innerHTML = ""

  document.getElementById("saveupdate").appendChild(crbtn);

  displayemployes()
}





function editemploye(i) {
  console.log(employes[i])
  myIndex = i;
  var updatebtn = document.createElement("button")
  updatebtn.innerHTML = "Update";
  updatebtn.setAttribute("class", "btn btn-sm btn-outline-primary")
  updatebtn.setAttribute("onclick", "updemploye()")
  document.getElementById("saveupdate").innerHTML = ""
  document.getElementById("saveupdate").appendChild(updatebtn);
  document.getElementById("employe-name").value = employes[i].name
  document.getElementById("employe-lname").value = employes[i].lname
  document.getElementById("employe-date").value = employes[i].date
  document.getElementById("employe-salary").value = employes[i].salary
  document.getElementById("employe-email").value = employes[i].email
  document.getElementById("employeedp").value = employes[i].employee
  document.getElementById("rbutton").value = employes[i].dp
  // document.getElementById("myCheck").value=employes[i].myCheck
}


function deleteemploye(i) {
  employes.splice(i, 1)
  displayemployes()
}





// function myFunction() {
//   var employee = document.forms[0];
//   var txt = "";
//   var i;
//   for (i = 0; i < employee.length; i++) {
//     if (employee[i].checked) {
//       txt = txt + employee[i].value + " ";
//     }
//   }
//   document.getElementById("employeedp").value = txt;
// }





// function checkButton() {
//   if (document.getElementById('php').checked) {
//     document.getElementById("disp").innerHTML
//       = document.getElementById("php").value

//   }
//   if (document.getElementById('java').checked) {
//     document.getElementById("disp").innerHTML
//       = document.getElementById("java").value
//   }
//   if (document.getElementById('html').checked) {
//     document.getElementById("disp").innerHTML
//       = document.getElementById("html").value

//   }


// }

// function getValue() {
//   var ele=[]
//    var bike = document.getElementById("checkbox1")
//    if(bike.checked){
//          ele.push(bike.value);
//   }
//   var car = document.getElementById("checkbox2")
//    if(car.checked){
//          ele.push(car.value);
//   }
//   var home = document.getElementById("checkbox3")
//    if(home.checked){
//          ele.push(home.value);
//   }
//     if(ele.length>0){
//      document.getElementById("employeedp").innerHTML = ele;
//     }
//     else{
//     document.getElementById("employeedp").innerHTML = "You Dont have any thing";
//     }
//   }

// function showname(){
//   var  file = document.form1.uploadBox.value ;
//   document.form1.filename.value = file ;
// }
// function preview() {
//   let frame = document.getElementById('frame');
//   frame.src = URL.createObjectURL(event.target.files[0]);
// }


// const chooseFile = document.getElementById("choose-file");
// const imgPreview = document.getElementById("img-preview");

// chooseFile.addEventListener("change", function () {
//   getImgData();
// });

// function getImgData() {
//   const files = chooseFile.files[0];
//   if (files) {
//     const fileReader = new FileReader();
//     fileReader.readAsDataURL(files);
//     fileReader.addEventListener("load", function () {
//       imgPreview.style.display = "block";
//       imgPreview.innerHTML = '<img src="' + this.result + '" />';
//     });
//   }
// }
