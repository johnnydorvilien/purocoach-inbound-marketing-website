
  
  function addRecord() {
    var fName = document.getElementById("first_name");
    var lName = document.getElementById("last_name");
    var email = document.getElementById("email");
    var dateDate = document.getElementById("date");
    var salary = document.getElementById("salary");
    var submit_btn = document.getElementById("save");
    var table = document.getElementById("employee_table");
    var error_msg = document.getElementById("error_msg");
    var row;
    var cell1;
    var cell2;
    var cell3;
    var cell4;
    var cell5;
    var cell6;
    var cell7;
  
  
    if (fName.value === "") {
     
      error_msg.innerHTML = " Please enter First Name ";

      return;
    }
    if (lName.value === "") {
      
      error_msg.innerHTML = " Please enter Last name ";
      return;
    }
    if (email.value === "") {
   
      error_msg.innerHTML = " Please enter email ";
      return;
    }
    if (dateDate.value === "") {
      
      error_msg.innerHTML = " Please enter date Date ";
      return;
    }
    if (salary.value === "") {
      
      error_msg.innerHTML = " Please enter salary ";
      return;
    }
   
    row = table.insertRow(1);
    cell1 = row.insertCell(0);
    cell2 = row.insertCell(1);
    cell3 = row.insertCell(2);
    cell4 = row.insertCell(3);
    cell5 = row.insertCell(4);
    cell6 = row.insertCell(5);
    cell7 = row.insertCell(6);
    cell1.innerHTML = fName.value;
    cell2.innerHTML = lName.value;
    cell3.innerHTML = email.value;
    cell4.innerHTML = dateDate.value;
    cell5.innerHTML = salary.value;
    cell6.innerHTML = "<input type='button' value='Edit employee' onclick='editRecord(this)'/>";
    cell7.innerHTML = "<input type='button' value='Delete user' onclick='deleteRecord(this)' />";

    document.getElementById("myForm").reset();
  

    document.getElementById("first_name").value = first_name;
         document.getElementById("last_name").value = last_name;
         document.getElementById("email").value = email;
         document.getElementById("date").value = date;      
         document.getElementById("salary").value = salary;      
     
    // var actionTd=document.createElement("td")
    // var editBtn=document.createElement("button")
    // editBtn.innerHTML="Edit"
    // editBtn.setAttribute("class" , "btn btn-sm btn-primary")
    // editBtn.setAttribute("onclick" , "editClient("+i+")")
  }


  function displayemployes(){
    document.getElementById("form-list-employe-body").innerHTML=""
    for (i=0;i<employes.length;i++){
      var myTr=document.createElement("tr")
      for(a in employes[i]){
        var mytd=document.createElement("td")
        mytd.innerHTML=employes[i][a]
        myTr.appendChild(mytd)
      }
      var actionTd=document.createElement("td")
      var editBtn=document.createElement("button")
      editBtn.innerHTML="Edit"
      editBtn.setAttribute("class" , "btn ")
      editBtn.setAttribute("onclick" , "editemploye("+i+")")

      var deletebtn=document.createElement("button")
      deletebtn.innerHTML="Delete"
      deletebtn.setAttribute("class" , "btn  ")
      deletebtn.setAttribute("onclick" , "deleteemploye("+i+")")

      actionTd.appendChild(editBtn)
      actionTd.appendChild(deletebtn)
      myTr.appendChild(actionTd)
      document.getElementById("form-list-employe-body").appendChild(myTr)

      }
      document.getElementById("employe-name").value="";
      document.getElementById("employe-lname").value="";
      document.getElementById("employe-date").value="";
      document.getElementById("employe-salary").value="";
      document.getElementById("employe-email").value="";
  }

  function editemploye(i){
    console.log(employes[i])
    myIndex=i;
    var updatebtn=document.createElement("button")
    updatebtn.innerHTML="Update";
    updatebtn.setAttribute("class", "btn btn-sm btn-success")
    updatebtn.setAttribute("onclick","updemploye()")
    document.getElementById("saveupdate").innerHTML=""
    document.getElementById("saveupdate").appendChild(updatebtn);
    document.getElementById("employe-name").value=employes[i].name
    document.getElementById("employe-lname").value=employes[i].lname
    document.getElementById("employe-date").value=employes[i].date
    document.getElementById("employe-salary").value=employes[i].salary
    document.getElementById("employe-email").value=employes[i].email
  }

//   function editemployee(submit_btn){
        

//     document.getElementById("first_name").value = first_name;
//     document.getElementById("last_name").value = last_name;
//     document.getElementById("email").value = email;
//     document.getElementById("date").value = date;      
//     document.getElementById("salary").value = salary;      
// }

  
  function deleteRecord(button) {
    var table = document.getElementById("employee_table");
    var row = button.parentNode.parentNode;
    table.deleteRow(row.rowIndex);
  }
  
  // function editRecord(button) {
  //   var row = button.parentNode.parentNode;
  //   var td_array = row.children;
  //   for (i = 0; i < td_array.length - 2; i++) { 
  //     td_array[i].setAttribute("contenteditable", "true");
  //   }
  
  //   button.parentNode.innerHTML = "<input type='button' style='background-color:lightblue' value='Exit edit mode' onclick='exitRecord(this)'/>";
  // }
  
  // function exitRecord(button) {
  //   var row = button.parentNode.parentNode;
  
  //   var td_array = row.children;
  //   for (i = 0; i < td_array.length - 2; i++) { 
  //     td_array[i].setAttribute("contenteditable", "false");
  //   }
  //   button.parentNode.innerHTML = "<input type='button' value='Edit employee' onclick='editRecord(this)'/>"
  
  // }
  
//   function addRecord() {
    
//   }

//   function updemploye(){
//     var updatedemploye={
//       name:document.getElementById("employe-name").value,
//       name:document.getElementById("employe-lname").value,
//       name:document.getElementById("employe-date").value,
//       name:document.getElementById("employe-salary").value,
//       email:document.getElementById("employe-email").value,
//     }
//     employes[myIndex]=updatedemploye;
//     var crbtn=document.createElement("button")
//     crbtn.innerHTML="Save";
//     crbtn.setAttribute("onclick","addemploye()")
//     crbtn.setAttribute("class","btn btn-sm btn-success")
//     document.getElementById("saveupdate").innerHTML=""
    
//     document.getElementById("saveupdate").appendChild(crbtn);
    
//     displayemployes()
//   }